#pragma OPTIONAL myfifa_header
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "datatype.h"

#ifndef OPTIONAL_H_
#define OPTIONAL_H_
/*
	This is the optional library that is used for peripheral purposes
	It could be for coloring or setting a timer or displaying the time.
	Each is further explained in each function
*/

//This function is going to act as a header image for displaying an image of code
//embedded in txt files included in the dirctory of [src]
void header()
{
	srand(time(NULL));
	int a = 1 + rand() % 7;
	switch(a)
	{
		case 1:
			system("more ../src/1.txt");
			break;
		case 2:
			system("more ../src/2.txt");
			break;
		case 3:
			system("more ../src/3.txt");
			break;
		case 4:
			system("more ../src/4.txt");
			break;
		case 5:
			system("more ../src/5.txt");
			break;
		case 6:
			system("more ../src/6.txt");
			break;
		case 7:
			system("more ../src/7.txt");
			break;
	} 
}

//This function pauses the console until the user presses a key on his keyboard
inline void pause()
{
	system("../build/pause.sh");
}

//This function has the job and it is to make the console wait for t seconds
void wait(int t)
{
	int start = time(NULL);
	int stop = t + start;
	for(;stop != start; start=time(NULL));
}

//This function tries to print out the system time
void now()
{
	time_t lt = time(NULL);
	cout << ctime(&lt) << endl;
}
/*
	This color codes are codes only designed for linux opreating systems. They are stored in each of their
	defining variables.
*/
void color(int a)
{
	// Colors * Foreground
	const std::string black("\033[0;30m");
	const std::string red("\033[0;31m");
	const std::string green("\033[0;32m");
	const std::string yellow("\033[0;33m");
	const std::string blue("\033[0;34m");
	const std::string magneta("\033[0;35m");
	const std::string cyan("\033[0;36m");
	const std::string white("\033[0;37m");
	//Controlles
	const std::string reset("\033[0m");
	const std::string underline("\033[4m");
	const std::string bold("\033[0m");
	const std::string bold1("\033[21m");
	const std::string underline1("\033[24m");
	const std::string inverse("\033[27m");
	switch(a)
	{
		case 1:
			cout << black;
			break;
		case 2:
			cout << red;
			break;
		case 3:
			cout << green;
			break;
		case 4:
			cout << yellow;
			break;
		case 5:
			cout << blue;
			break;
		case 6:
			cout << magneta;
			break;
		case 7:
			cout << cyan;
			break;
		case 8:
			cout << white;
			break;
		case 0:
			cout << reset;
			break;
		case -1:
			cout << underline;
			break;
		case -2:
			cout << bold;
			break;
		case -3:
			cout << bold1;
			break;
		case -4:
			cout << underline1;
			break;
		case -5:
			cout << inverse;
			break;
		default:
			cout << "Bad input of color.\n";
	}
}
#endif
