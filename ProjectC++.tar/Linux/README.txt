==================================================================================================================
==================================================================================================================
											MY FIFA
==================================================================================================================

	This software is created for managment purposes of teams and players. It makes has certain functions that are helpful to a manager. It is mainly built by C++ and  therefore it is so fast to act on. For this version there has been no installation or setup you can just run it from the console.
	This README is for the linux version of the program. If you're on Windows or on Mac this program won't work for you. So I advise you to use the windows version instead.
	-------------------------------------------------------------------------------------------------------------
	To run the program. Go to MYFIFA, the to the build directory and then open terminal there. You don't have to be root. Then write the command in the square brackets.[./main]

	Enjoy!
================================================================================================================