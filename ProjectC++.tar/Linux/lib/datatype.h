#pragma DATATYPE a user definer header file
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

#ifndef SAMICLASS_H_
#define SAMICLASS_H_

/*
	This Library includes all of the classes and datatypes that MYFIFA is going to have.
	Several of the methodes and structures are metioned below
*/

class Player {
	private:
		string pname, tname, position, nationality;
		int age, kitnumber, id;
		double salary;

	public:
		//DEFAULT CONSTRUCTER
		Player()
		{
			id = 1;
			pname = "";
			tname = "";
			position = "";
			nationality = "";
			age = 0;
			kitnumber = 0;
			salary = 0;
		}

		bool available()
		{
			if (id == 1)
				return true;
			else
				return false;
		}

		void deletePlayer()
		{
			id = 0;
		}

		//SET METHOD
		void setID(int a)
		{
			id = a;
		}

		void setPName(string p)
		{
			pname = p;
		}
		
		void setTName(string p)
		{
			tname = p;
		}
		void setPostion(string p)
		{
			position = p;
		}
		void setNationality(string p)
		{
			nationality = p;
		}
		void setAge(int p)
		{
			age = p;
		}
		void setKitNumber(int p)
		{
			kitnumber = p;
		}
		void setSalary(double p)
		{
			salary = p;
		}
		//GET METHOD
		
		int getID()
		{
			return id;
		}

		string getPName()
		{
			return pname;
		}
		string getTName()
		{
			return tname;
		}
		string getNationality()
		{
			return nationality;
			
		}
		string getPosition()
		{
			return position;
		}
		int getKitNumber()
		{
			return kitnumber;
		}
		double getSalary()
		{
			return salary;
		}
		int getAge()
		{
			return age;
		}
};


struct _player {
		string _pname, _tname, _position, _nationality;
		int _age, _kitnumber; double _salary, _id;
};


#endif
