#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <iomanip>
#include <ctime>
#include "datatype.h"
#include "optional.h"

#ifndef MODULES_H_
#define MODULES_H_

/*
	This Library includes all of the functionalities that MYFIFA is going to have.
	Several of the functionalities are metioned below
*/

int j = 0;

//Structure needed for writing teams on team.txt
struct _pl{
		string team_n;
		int rank;
	}teams[30];

//Declaring Each function inorder to access them
void checkPlayer(Player *);
void load(Player *);
void viewAll(Player *);
void viewPlayer(Player);
void addPlayer();
void by_name(Player *);
void by_team(Player *);
void write_team(Player *p, int count);
int str_len(string);
struct _player writePlayer(_player);
struct _player pp;

//This function counts the number of players stored in player.txt and returns the number
//with an interger value
int count()
{
	int counter = 0;
	string s;
	ifstream infile("../src/player.txt", ios::in);
	while(!infile.eof())
	{
		infile >> s;
		counter++;
	}
	infile.close();
	return counter/10;
}

//This is the main or the basic function. Its purpose is to load all the information stored in
//player.txt into the arrar p, and then all the information is LOADED into our program and we
//can easily access it
void load(Player *p)
{
	ifstream infile("../src/player.txt", ios::in);
	string str;
	for (int i = 0; !infile.eof(); ++i)
	{
		getline(infile, str);
		getline(infile, str); p[i].setID(atoi(str.c_str()));
		getline(infile, str); p[i].setPName(str);
		getline(infile, str); p[i].setTName(str);
		getline(infile, str); p[i].setPostion(str);
		getline(infile, str); p[i].setNationality(str);
		infile >> str; p[i].setAge(atoi(str.c_str()));
		infile >> str; p[i].setKitNumber(atoi(str.c_str()));
		infile >> str; p[i].setSalary(atof(str.c_str()));
		infile >> str;
		infile >> str;
		j++;
	}
	infile.close();
}

//As the name suggets this function views all the players
void viewAll(Player *p)
{
	for (int i = 0; i < j; ++i)
	{
		if (!p[i].available())
			continue;
		printf("-------------------------------------------------------------------------------\n");
		cout << "Player Name: " << p[i].getPName()
			 << "\nTeam Name:  " << p[i].getTName()
			 << "\nPosition: " << p[i].getPosition()
			 << "\nNationality: " << p[i].getNationality()
			 << "\nAge: " << p[i].getAge()
			 << "\nKit Number: " << p[i].getKitNumber()
			 << "\nSalary: " << p[i].getSalary() << endl;
	}
	printf("-------------------------------------------------------------------------------\n");
}

//This function enables us to view one player
void viewPlayer(Player p)
{
	if(!p.available())
	{
		printf("Player has been deleted\n");
		goto c;
	}
	color(6);
	printf("========================================================\n");
	color(4);
	cout << "Player Name: " << p.getPName()
		 << "\nTeam Name:  " << p.getTName()
		 << "\nPosition: " << p.getPosition()
		 << "\nNationality: " << p.getNationality()
		 << "\nAge: " << p.getAge()
		 << "\nKit Number: " << p.getKitNumber()
		 << "\nSalary: " << p.getSalary() << endl;
	color(6);
	printf("========================================================\n");
	c:
	p;
}

//This funcition is for adding only a single player
void addPlayer(Player *p)
{
	color(0);
	string str; int a; double f;
	printf("Enter the details about the player\n");
	color(6); cout << "myfifa:add:name> "; 
	color(4); getline(cin, str); getline(cin, str); pp._pname = str;
	color(6); cout << "myfifa:add:teamname> "; 
	color(4); getline(cin, str); pp._tname = str;
	color(6); cout << "myfifa:add:position> ";
	color(4); getline(cin, str); pp._position = str;
	color(6); cout << "myfifa:add:nationality> ";
	color(4); getline(cin, str); pp._nationality = str;
	color(6); cout << "myfifa:add:age> "; 
	color(4); cin >> a; pp._age = a;
	color(6); cout << "myfifa:add:kitnumber> ";
	color(4); cin >> a; pp._kitnumber = a;
	color(6); cout << "myfifa:add:salary> ";
	color(4); cin >> f; pp._salary = f;
	writePlayer(pp);
}

//Writes a single player to player.txt
struct _player writePlayer(_player pp)
{
	ofstream outfile("../src/player.txt", ios::app);	
	outfile << "#start" << endl
			<< 1 << endl
			<< pp._pname << endl
			<< pp._tname << endl
			<< pp._position << endl
			<< pp._nationality << endl
			<< pp._age << endl
			<< pp._kitnumber << endl
			<< pp._salary << endl
			<< "#stop" << endl;
	return pp;
	outfile.close();
}

//Searches a player by its name
void by_name(Player *_p, string name, int counter)
{
	for (int i = 0; i < counter; ++i)
	{
		if (name == _p[i].getPName())
		{
			viewPlayer(_p[i]);
			goto End;
		}
		else
			continue;
	}
	cout << "Player NOT found.\n";
	End:
	name;
}

//Searches a team by its name and then displays the team if found
void by_team(Player *_p, string tname, int counter)
{
	string _player[100];
	int kit[100];
	string p[100];
	int k = 0;
	for (int i = 0; i < counter; ++i)
	{
		if (tname == _p[i].getTName())
		{
			if(_p[i].available())
			{
				_player[k] = _p[i].getPName();
				kit[k] = _p[i].getKitNumber();
				p[k] = _p[i].getPosition();
				k++;
			}
		}
	}
	int space[k];
	if (k == 0)
		printf("Team NOT found\n");
	else
	{
		for (int i = 0; i < k; ++i)
			space[i] = 23 - str_len(_player[i]);

		for (int i = 0; i < k; ++i)
			cout << _player[i] << setw(space[i]) << p[i] << setw(15) << kit[i] << endl; 
	}
}

//This function writes multiple players into the file player.txt
void _writePlayers(Player *p, int count)
{
	ofstream outfile1("../src/player.txt", ios::out);
	for (int i = 0; i < (count-4); ++i)
	{
		outfile1 << "#start" << endl
				 << p[i].getID() << endl
				 << p[i].getPName() << endl
				 << p[i].getTName() << endl
				 << p[i].getPosition() << endl
				 << p[i].getNationality() << endl
				 << p[i].getAge() << endl
				 << p[i].getKitNumber() << endl
				 << p[i].getSalary() << endl
				 << "#stop" << endl;
	}
	outfile1.close();
}

//An edit function that edits the name of the team
void editTeamName(Player *ppi, string str, string s, int count)
{
	bool a = true;
	for (int i = 0; i < count; ++i)
	{
		if (ppi[i].getTName() == str)
		{
			a = false;
			ppi[i].setTName(s);
		}
		else
			continue;
	}
	if (a)
		cout << "Team Doesn't Exist\n";
	else
	{
		_writePlayers(ppi, count);
		write_team(ppi, count);
	}
}

//This one adds players to a specific team
void addPlayerToTeam(Player *ppi, string str)
{
	string s;
	_player pp;
	printf("How many players you want to enter\n");
	cout << "myfifa:add> "; int prompt; cin >> prompt;
	for (int i = 0; i < prompt; ++i)
	{
			cout << "myfifa:add:name> "; getline(cin, s); getline(cin, s); pp._pname = s;
			pp._tname = str;
			color(6); cout << "myfifa:add:position> ";
			color(4); cin >> pp._position;
			color(6); cout << "myfifa:add:nationality> ";
			color(4); cin >> pp._nationality;
			color(6); cout << "myfifa:add:age> ";
			color(4); cin >> pp._age;
			color(6); cout << "myfifa:add:kitnumber> ";
			color(4); cin >> pp._kitnumber;
			color(6); cout << "myfifa:add:salary> ";
			color(4); cin >> pp._salary;
			writePlayer(pp);
	}
}

//This one delets a player, but it doesn't remove it from the file. It changes a simple thing
//An ID. Its the indicator of the player if its available of not
//If it's available the ID is set to 1, if its not the ID will set to be 0
//If its zero the player can not be displayed, by viewAll() or by viewPlayer()
void deletePlayer(Player *pp, string name, int count)
{
	bool a = true;
	for (int i = 0; i < count; ++i)
	{
		if (name == pp[i].getPName())
		{
			a = false;
			if (pp[i].getID() == 0)
			{
				printf("Player has already been deleted.\n");
				goto _d;
			}
			pp[i].setID(0);
		}
	}
	if (a)
		cout << "Player NOT Found.\n";
	else
	{
		_writePlayers(pp, count);
		printf("Player Deleted\n");
	}
	_d:
	name;
}

void recoverPlayer(Player *pp, string name, int count)
{
	bool a = true;
	for (int i = 0; i < count; ++i)
	{
		if (name == pp[i].getPName())
		{
			a = false;
			if (pp[i].getID() == 1)
			{
				printf("Player hasn't been deleted.\n");
				goto _d;
			}
			pp[i].setID(1);
		}
	}
	if (a)
		cout << "Player NOT Found.\n";
	else
	{
		_writePlayers(pp, count);
		printf("Player Recoverd\n");
	}
	_d:
	name;
}

//This one removes a player from a team. Its basically is the same as delete player
//But this time we need to specify a team name and a player name
void removePlayerFromTeam(Player *ppi, string team, string name, int count)
{
	for (int i = 0; i < count; ++i)
	{
		if (ppi[i].getTName() == team)
		{
			if (ppi[i].getPName() == name)
			{
				ppi[i].setID(0);
				goto del;
			}
		}
	}
	cout << "Player Doesn't Exist.\n"; goto eND;
	del:
	_writePlayers(ppi, count);
	eND:
	name;
}

//This is the functionality that ties to edit a player
int editPlayer(Player *p, string name, int count)
{
	color(0);
	string s; double f; int a;
	int prompt;
	for (int i = 0; i < count; ++i)
	{
		if (name == p[i].getPName())
		{
			if (!p[i].available())
			{
				cout << "Player has been deleted.\n";
				return 1;
			}
			printf("Select from the menu: \n\n");
			cout << "\t1. Change Name\n\t2. Change Team\n\t3. Change Position\n\t4. Change Nationality"
				 << "\n\t5. Change Age\n\t6. Change Kit Number\n\t7. Change Salary\n\t99. Return to above menu\n\n";
			cout << "myfifa:edit:player> "; cin >> prompt;
			switch(prompt)
			{
				case 1:
				printf("Enter a new name\n");
				color(6); cout << "myfifa:edit:name> ";
				color(4); getline(cin, s); getline(cin, s); p[i].setPName(s);
				cout << "Player name changed.\n"; goto ENF;
				case 2:
				printf("Enter a new Team Name\n");
				color(6); cout << "myfifa:edit:tname> ";
				color(4); getline(cin, s); getline(cin, s); p[i].setTName(s);
				cout << "Player team name changed.\n"; goto ENF;
				case 3:
				printf("Enter a new Position\n");
				color(6); cout << "myfifa:edit:position> ";
				color(4); getline(cin, s); p[i].setPostion(s);
				cout << "Player position changed.\n";goto ENF;
				case 4:
				printf("Enter a new Nationality\n");
				color(6); cout << "myfifa:edit:nationality> ";
				color(4); getline(cin, s); getline(cin, s); p[i].setNationality(s); goto ENF;
				case 5:
				printf("Enter a new Age\n");
				color(6); cout << "myfifa:edit:age> ";
				color(4); cin >> a; p[i].setAge(a); goto ENF;
				case 6:
				printf("Enter a new Kit Number\n");
				color(6); cout << "myfifa:edit:kitnumber> ";
				color(4); cin >> a; p[i].setKitNumber(a); goto ENF;
				case 7:
				printf("Enter a new Salary\n");
				color(6); cout << "myfifa:edit:salary> ";
				color(4); cin >> f; p[i].setSalary(f); goto ENF;
				case 99: return 99;
			}
		}
	}
	printf("Player NOT Found\n");
	ENF:
	_writePlayers(p, count);
}

//This one tries to edit the information of the team. If you can see from the menu there are
//different functionalities to it
void edit_team(Player *p, string str, int count)
{
	color(0);
	string ss;
	printf("Select from the menu\n\n1. Edit Team Name\n2. Add Players\n3. Remove Players\n99. Return Back to Menu\n\n");
	int prompt;
	color(6); cout << "myfifa:edit:team> ";
	color(4); cin >> ss; prompt = atoi(ss.c_str());
	string s;
	color(0);
	switch(prompt)
	{
		case 1:
			cout << "Enter new Team's name\n";
			color(6);
			cout << "myfifa:edit:team:name> ";
			color(4); getline(cin, s); getline(cin, s); editTeamName(p, str, s, count);
			break;
		case 2:
			addPlayerToTeam(p, str); 
			break;
		case 3:
			cout << "Enter the player you want to remove.\n";
			color(6); cout << "myfifa:edit:team:remove> ";
			color(4); getline(cin, s); getline(cin, s);removePlayerFromTeam(p, str, s, count);
			break;
		case 99:
			goto END;
	}
	END:
	str;
}

//This one sort the player names stored in the array p in ascending order
void asort(Player *p, int count)
{
	string _player[count], temp, first, second;
	for (int i = 0; i < count; ++i)
		_player[i] = p[i].getPName();
	for (int i = 0; i < count; ++i)
	{
		for (int j = 0; j < count; ++j)
		{
			first = _player[j]; second = _player[j+1];
			if (first > second)
			{
				temp = _player[j+1];
				_player[j+1] = _player[j];
				_player[j] = temp;
			}
		}
	}
	for (int i = 5; i < (count); ++i)
	{
		cout << _player[i] << endl;
	}
	
}

//This function sort the player names stored in player.txt in descending order
void dsort(Player *p, int count)
{
	string _player[count], temp, first, second;
	for (int i = 0; i < count; ++i)
		_player[i] = p[i].getPName();
	for (int i = 0; i < count; ++i)
	{
		for (int j = 0; j < count; ++j)
		{
			first = _player[j]; second = _player[j+1];
			if (first < second)
			{
				temp = _player[j+1];
				_player[j+1] = _player[j];
				_player[j] = temp;
			}
		}
	}
	for (int i = 0; i < count - 4; ++i)
	{
		cout << _player[i] << endl;
	}
	
}

//This one tries to write the teams to team.txt
void write_team(Player *p, int count)
{
	int m = 0;
	ofstream outfile("../src/team.txt", ios::out);
	string team[count], str;

	for (int i = 0; i < count; ++i)
		team[i] = "NULL";
	bool a = false;
	for (int i = 0; i < count; ++i)
	{
		a = true;
		str = p[i].getTName();
		for (int i = 0; i < count; ++i)
		{
			if (str == team[i])
				a = false;
		}
		if (a)
		{
			team[m] = str;
			m++;
		}
	}
	for (int i = 0; i < m; ++i)
		outfile << team[i] << endl;
	outfile.close();
}

//This boolean function, checks wheather the team exists or not
//if it exists it returns a boolean value of true, but if not it return a boolean value of false
bool checkTeam(string str)
{
	string s;
	ifstream infile("../src/team.txt", ios::in);
	while(!infile.eof())
	{
		getline(infile, s);
		if (s == str)
		{
			infile.close();
			return true;
		}
	}
	infile.close();
	return false;
}

//This special funcition is relatively called inside the tournament function
//It generates random numbers and assigns fixtures for the team avaiable in team.txt
//Then it displays the fixtures
void viewFixtures()
{
	ifstream infile("../src/team.txt", ios::in);
	int a[10], b[10], temp;
	string s, teams[30];
	srand(time(NULL));
	system("clear");
	color(7);
	printf("Loading Fixtures, please wait for 20 seconds.\n");
	for (int i = 0; i < 10; ++i)
	{
		a[i] = rand() % 20;
		wait(1);
		b[i] = rand() % 20;
		wait(1);
	}
	getline(infile, s);
	for (int i = 0; !infile.eof(); ++i)
	{
		getline(infile, s);
		teams[i] = s;
	}
	color(6);
	printf("=======================================================================\n");
	color(3); printf("\t\t\t\tFixtures\n"); color(5);
	printf("-----------------------------------------------------------------------\n");
	for (int i = 0; i < 10; ++i)
	{
		temp = a[i];
		color(2);
		cout << "\t\t" << teams[temp];
		color(3); cout << " Vs "; color(2);
		temp = b[i];
		cout << teams[temp] << endl;
	}	
	color(6);
	printf("========================================================================\n");
	infile.close();
	color(0);
}

int str_len(string s)
{
	int count = 0;
	for (int i = 0; s[i] != '\0'; ++i)
		count++;
	return count;
}

//This whole function prints out the rankings of the teams that are found on team.txt
void viewRankings()
{
	system("clear");
	int p = 34;
	int space[20], length[20];
	string s;
	ifstream infile("../src/team.txt", ios::in);
	getline(infile, s);
	for (int i = 0; !infile.eof(); ++i)
	{
		getline(infile, s);
		teams[i].team_n = s;		
	}
	
	for (int i = 0; i < 20; ++i)
	{
		s = teams[i].team_n;
		space[i] = 26 - str_len(s);
	}

	color(6); printf("\t\tLeague Table\n");
	color(5); printf("Rank\tName\t\t\tPoints   \tGF\tGA\tGD\n"); color(7);
	printf("------------------------------------------------------------------------------------------\n");
	color(4); 
	cout << 1 << setw(9) << "" << teams[0].team_n  << "" << setw(space[0]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 2 << setw(9) << "" << teams[1].team_n  << "" << setw(space[1]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 3 << setw(9) << "" << teams[2].team_n  << "" << setw(space[2]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 4 << setw(9) << "" << teams[3].team_n  << "" << setw(space[3]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 5 << setw(9) << "" << teams[4].team_n  << "" << setw(space[4]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 6 << setw(9) << "" << teams[5].team_n  << "" << setw(space[5]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 7 << setw(9) << "" << teams[6].team_n  << "" << setw(space[6]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 8 << setw(9) << "" << teams[7].team_n  << "" << setw(space[7]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 9 << setw(9) << "" << teams[8].team_n  << "" << setw(space[8]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 10 << setw(8) << "" << teams[9].team_n  << "" << setw(space[9]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 11 << setw(8) << "" << teams[10].team_n  << "" << setw(space[10]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 12 << setw(8) << "" << teams[11].team_n  << "" << setw(space[11]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 13 << setw(8) << "" << teams[12].team_n  << "" << setw(space[12]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 14 << setw(8) << "" << teams[13].team_n  << "" << setw(space[13]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 15 << setw(8) << "" << teams[14].team_n  << "" << setw(space[14]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 16 << setw(8) << "" << teams[15].team_n  << "" << setw(space[15]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 17 << setw(8) << "" << teams[16].team_n  << "" << setw(space[16]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 18 << setw(8) << "" << teams[17].team_n  << "" << setw(space[17]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 19 << setw(8) << "" << teams[18].team_n  << "" << setw(space[18]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	cout << 20 << setw(8) << "" << teams[19].team_n  << "" << setw(space[19]) << "" << setw(2) << --p << setw(10) << "" << p*2  << "" << setw(9) << p/2 << setw(7) << p*2 - p/2 << endl;
	color(0);
}

//This is a function that is called on the main.cpp and that tries to call two function with in it
//These funcitons include viewFixture() and viewRankings()
int tournament()
{
	string s;
	int prompt;
	color(0);
	printf("\t\t\tChampions League\n");
	t:
	printf("Select an option: \n");
	printf("\t1. View Fixtures\n\t2. View Rankings\n\t99. Return Back to Menu\n\n");
	S_:
	color(6);
	cout << "myfifa:table> "; color(4); cin >> s; prompt = atoi(s.c_str());
	color(0);
	switch(prompt)
	{
		case 1: viewFixtures(); pause(); goto t;
		case 2: viewRankings(); pause(); goto t;
		case 99: return 1;
		default: printf("Invalid Option\n"); goto S_;
	}
	
}

bool checkPlayer(string pName)
{
	string str;
	ifstream infile("../src/player.txt", ios::in);
	getline(infile, str); getline(infile, str);
	while(!infile.eof())
	{
		getline(infile, str);
		if (str == pName)
		{
			return true;
			break;
		}
		for (int i = 0; i < 9; ++i)
			getline(infile, str);
	}
	return false;
}

int indexPlayer(Player *p, int count, string name)
{
	for (int i = 0; i < count; ++i)
	{
		if(name == p[i].getPName())
			return i;
	}
	return 0;
}

int transfer(Player *p, int count)
{
	int i;
	string str;
	printf("Enter the name of the player you want to transfer\n");
	color(6);
	cout << "myfifa:transfer> "; color(4); getline(cin, str); getline(cin, str);
	i = indexPlayer(p, count, str);
	if (!p[i].available())
	{
		printf("Player has been deleted\n");
		return -2;
	}
	if (checkPlayer(str))
	{
		color(5);
		cout << "Enter the team you want to transfer " << str << endl;
		_A:
		color(6); cout << "myfifa:transfer> "; color(4); getline(cin, str);
		color(4);
		if(checkTeam(str))
		{
			p[i].setTName(str);
			printf("Transfer Successfull\n");
		}
		else
		{
			cout << "Team doesn't exist\n";
			goto _A;
		}

	}
	else
	{
		printf("Player doesn't exist.\n");
		return -1;
	}
}

#endif
